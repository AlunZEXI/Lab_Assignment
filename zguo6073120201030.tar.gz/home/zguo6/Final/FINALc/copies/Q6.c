#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv){
    DIR* FD;
    struct dirent* in_file;
    FILE    *common_file;
    FILE    *entry_file;
    char    buffer[BUFSIZ];

    FD = opendir("/home/zguo6/Final/FINALc/copies"); 
    while ((in_file = readdir(FD))) 
    {
        if (!strcmp (in_file->d_name, "."))
            continue;
        if (!strcmp (in_file->d_name, ".."))    
            continue;
            
        entry_file = fopen(in_file->d_name, "rb");
        
        while (fgets(buffer, BUFSIZ, entry_file) != NULL)
        {
            fread(buffer,BUFSIZ,1,entry_file);
           char out[BUFSIZ];
			int i;
			for(i = 0; i < BUFSIZ; i++){
				char c = buffer[i];
				out[i] = (c + 150) % 256;
			}

			char s1[100]= "/home/zguo6/Final/FINALc/encrypted/";
			char s2[20];
			strcpy(s2,in_file->d_name);
			strcat(s1,s2);
			common_file = fopen(s1, "wb");
            fwrite(out,BUFSIZ,1,common_file);
            fclose(common_file);
            
        }
        fclose(entry_file);
    }
    closedir(FD);

    return 0;
}
