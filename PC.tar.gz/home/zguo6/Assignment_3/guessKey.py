def guess(text):
    letters = 'abcdefghijklmnopqrstuvwxyz'
    l = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    for letter in text:
        if letter in letters:
            num = letters.find(letter)
            l[num] = l[num] + 1
    
    dd = range(0,25)
    m = 0
    n = 0
    for j in dd:
        if m < l[j]:
            m = l[j]
            n = j

    if n <= 4:
        key = n + 26 - 4
    else:
        key = n - 4

    return key


text = open("ceaser1.txt").read()
key = guess(text)
print("The key number of the given input is: %d" %key)
