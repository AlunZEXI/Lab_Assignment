#!/bin/bash
echo "The sum of strings: "
awk 'BEGIN{sum=0}{sum+=$0}END{print sum}' /home/zguo6/Lab3_2/toknut.txt | ./knuttostring.sh 

