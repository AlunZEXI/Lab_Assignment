#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{	
	printf("Input your key number: ");
    int key;
    scanf("%d", &key);
	
	printf("Input your code and I will encrypt it for you: ");
    
    
    char ch, c[10000];
FILE *fp;
int l=0;
fp = fopen("message1.txt","r");
if(fp == NULL){
printf("Error \n");
exit(0);
}
while((ch = fgetc(fp)) != EOF){
c[l] = ch;
l++;
}
fclose(fp);

    int len = strlen(c);
    int i;
    for (i = 0; i < len; i++)
    {
        if ((c[i] >= 'a' && c[i] <= 'z') || (c[i] >= 'A' && c[i] <= 'Z'))
        {
            if ((c[i] >= 'z'-key && c[i] <= 'z') || (c[i] >= 'Z'-key && c[i] <= 'Z'))
            {
                c[i] = c[i] - 26 + key;
            }
            else
                c[i] = c[i] + key;
        }
    }
    int j;
    for(j=0; j < len; j++){
    	c[j] = tolower(c[j]);
	}
    printf("%s", c);
    printf("\n");
    return 0;
}
