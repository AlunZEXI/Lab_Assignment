#!/bin/bash

awk


'{sum=0}
BEGIN {sum += $0}
 END {print sum}'
