#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char **argv){
    DIR* FD;
    struct dirent* in_file;
    FILE    *common_file;
    FILE    *entry_file;
    FILE    *write_file;
    char    buffer[BUFSIZ];

    

    if (NULL == (FD = opendir ("/home/zguo6/Final/FINALc/copies"))) 
    {
        fprintf(stderr, "Error : Failed to open input directory - %s\n", strerror(errno));
        fclose(common_file);

        return 1;
    }
    while ((in_file = readdir(FD))) 
    {
        if (!strcmp (in_file->d_name, "."))
            continue;
        if (!strcmp (in_file->d_name, ".."))    
            continue;
        entry_file = fopen(in_file->d_name, "rb");
        if (entry_file == NULL)
        {
            fprintf(stderr, "Error : Failed to open entry file - %s\n", strerror(errno));
            fclose(common_file);

            return 1;
        }
        
        while (fgets(buffer, BUFSIZ, entry_file) != NULL)
        {
            fread(buffer,BUFSIZ,1,entry_file);
            char out[sizeof buffer];
			int i;
			for(i = 0; i < sizeof buffer; i++){
				out[i] = (buffer[i] + 150) % 256;
			}
			char * s1 = "/home/zguo6/Final/FINALc/encrypted/";
			char * s2 = in_file->d_name;
			strcat(s1,s2);
			common_file = fopen(s1, "wb");
    		if (common_file == NULL)
    		{
        		fprintf(stderr, "Error : Failed to open common_file - %s\n", strerror(errno));

        		return 1;
    		}
            fwrite(out,sizeof out,1,common_file);
		fclose(common_file);
        }

        fclose(entry_file);
    }


    return 0;
}
