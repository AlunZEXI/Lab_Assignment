#!/bin/bash

echo "#7Mean: "
awk 'BEGIN{sum=0; count=0}{sum+=$7; count+=1}END{sum/=count; print sum}' /home/zguo6/Lab3_1/Q4data 

echo "#8Mean: "
awk 'BEGIN{sum=0; count=0}{sum+=$8; count+=1}END{sum/=count; print sum}' /home/zguo6/Lab3_1/Q4data

echo "#9Mean: "
awk 'BEGIN{sum=0; count=0}{sum+=$9; count+=1}END{sum/=count; print sum}' /home/zguo6/Lab3_1/Q4data

