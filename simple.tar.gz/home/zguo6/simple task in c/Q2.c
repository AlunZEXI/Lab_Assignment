#include<stdio.h>
#define max 100
int main(){

printf("Input string: ");

char input[max];
scanf("%s", input);
int output;
output = atoi (input);
printf("The int value of the string is %d \n", output);
return 0;
}
