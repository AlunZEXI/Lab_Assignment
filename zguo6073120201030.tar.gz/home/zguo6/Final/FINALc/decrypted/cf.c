dio.h>
#include <stdlib.h>
#include <string.h>
int main() {
	char c1[50];
	char c2[50];
	char c3[50];
	char c4[50];
	char c5[50];
	
	strcpy(c1,"mkdir FINALc");
	system(c1);
	
	strcpy(c2,"cp cf.c FINALc");
	system(c2);
	
	strcpy(c3,"mkdir -p /home/zguo6/Final/FINALc/copies");
	system(c3);
	
	strcpy(c4,"mkdir -p /home/zguo6/Final/FINALc/encrypted");
	system(c4);
	
	strcpy(c5,"mkdir -p /home/zguo6/Final/FINALc/decrypted");
	system(c5);
	
	return 0;
}

