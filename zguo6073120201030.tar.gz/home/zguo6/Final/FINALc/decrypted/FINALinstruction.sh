put
awk '{if($1 != "total"){print $1, $9}else{print $0}}' output >> FINALinstruction
opies")
system("mkdir -p /home/zguo6/Final/FINALpython/encrypted")
system("mkdir -p /home/zguo6/Final/FINALpython/decrypted")

