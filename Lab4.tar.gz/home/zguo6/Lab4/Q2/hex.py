import sys
import binascii
def hexsss(readfile, writefile):
    hstr = ""
    byte = ""
    print("char, ascii, hex")
    with open(readfile, "rb") as data:
        byte = data.read(1)
        while byte != "":
            print(byte, ord(byte), hex(ord(byte)))
            hstr += binascii.hexlify(byte)
            byte = data.read(1)
    print("Hex string: ")
    print(hstr)
    f = open(writefile,"w")
    f.write(hstr)
    f.close()

hexsss("hex.txt","hex_dump")
