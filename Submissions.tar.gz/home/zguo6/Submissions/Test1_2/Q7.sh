#!/bin/bash

awk '{if($3!="Black" && $3!="White" && $3!="\"Hispanic") print $3}' 2.asr
