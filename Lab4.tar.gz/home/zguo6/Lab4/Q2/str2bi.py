import string
import binascii
inp = raw_input("Please enter your string: ")
print("Binary code: ")
inp.replace(" ","")
bi = binascii.a2b_base64(inp.strip())
print(bi)
