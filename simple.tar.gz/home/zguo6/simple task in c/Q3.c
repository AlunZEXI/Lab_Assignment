#include<stdio.h>

int main(){
printf("Input your year: ");
int input;
scanf("%d", &input);
if(input % 4 == 0){
if (input % 100==0 && input %400 !=0){
printf("This is a normal year.\n");
}
else{
printf("This is a leap year.\n");
}
}
else{
printf("This is a normal year.\n");
}


return 0;
}
