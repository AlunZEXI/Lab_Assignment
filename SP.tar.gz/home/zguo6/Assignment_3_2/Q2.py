integer = raw_input("Enter your int: ")
a = int(integer)
print(a)
print("It is a: ")
print(type(a))

