#include<stdio.h>
#include<stdlib.h>

void main(){
char ch;
FILE *fp;
fp = fopen("ceaser1.txt","r");
if(fp == NULL){
printf("Error \n");
exit(0);
}
printf("\n\n");
while((ch = fgetc(fp)) != EOF){
printf("%c" , ch);
}

printf("\n \n");
fclose(fp);
}

