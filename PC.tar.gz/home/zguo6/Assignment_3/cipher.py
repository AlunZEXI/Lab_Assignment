def encrypt(text,s):
    result = ""
    for i in range(len(text)):
      char = text[i]
      if (char.isupper()):
         char = char.lower()
      if(char.isalpha()):
         result += chr((ord(char) + s - 97) % 26 + 97)
      else:
         result += char
    return result

text = open("ceaser1.txt").read()
s = input("Please input your key number: ")

print ("Cipher: " + encrypt(text,s))
