#!/bin/bash

awk '{

	symbol="";

	if(substr($0,1,1)=="-"){
		symbol="-"
	};

	gsub("-","",$0);

	split($0,fct,"/");

	#print fct[1], fct[2], fct[3];

	knuts = fct[1]*23*17 + fct[2]*17 + fct[3];

	if(symbol=="-"){
		knuts=-knuts
	};

	print knuts;
}'
