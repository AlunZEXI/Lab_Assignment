import binascii
def dehex(hexfile):
    data = open(hexfile,"r").read()
    unhex = binascii.unhexlify(data)
    print(unhex)

dehex("hex_dump")
