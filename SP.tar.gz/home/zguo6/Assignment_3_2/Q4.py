count = 0
for i in range(1,999):
    if i % 3 == 0 or i % 5 == 0:
        count = count + i

print(count)
