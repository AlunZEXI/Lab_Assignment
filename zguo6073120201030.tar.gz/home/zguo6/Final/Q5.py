from os import system

command1 = "awk '{if($1 != 'total' ){print $2}}' FINALinstruction >> Q5input"
system(command1)
command2 = "xargs -a Q5input cp -t /home/zguo6/Final/FINALc/copies"
system(command2)
