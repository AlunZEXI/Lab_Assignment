#!/bin/bash

echo "White Male: "
echo "Total number: "
awk -F, 'BEGIN{count=0;}{if($5=="Male" && $6=="White") count++;}END{print count}' 2.parse 
echo "Average Age: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Male" && $6=="White") count++;if($5=="Male" && $6=="White") age+=$4;}END{age/=count; print age}' 2.parse
echo "Min Age: "
awk -F, 'BEGIN{min=200;}{if($5=="Male" && $6=="White" && $4<=min) min=$4 }END{print min}' 2.parse
echo "Max Age: "
awk -F, 'BEGIN{max=0;}{if($5=="Male" && $6=="White" && $4>=max) max=$4 }END{print max}' 2.parse

echo "----------"
echo "White Female: "
echo "Total number: "
awk -F, 'BEGIN{count=0;}{if($5=="Female" && $6=="White") count++;}END{print count}' 2.parse
echo "Average Age: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Female" && $6=="White") count++;if($5=="Female" && $6=="White") age+=$4;}END{age/=count; print age}' 2.parse
echo "Min Age: "
awk -F, 'BEGIN{min=200;}{if($5=="Female" && $6=="White" && $4<=min) min=$4 }END{print min}' 2.parse
echo "Max Age: "
awk -F, 'BEGIN{max=0;}{if($5=="Female" && $6=="White" && $4>=max) max=$4 }END{print max}' 2.parse

echo "---------"
echo "Black Male: "
echo "Total number: "
awk -F, 'BEGIN{count=0;}{if($5=="Male" && $6=="Black") count++;}END{print count}' 2.parse
echo "Average Age: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Male" && $6=="Black") count++;if($5=="Male" && $6=="Black") age+=$4;}END{age/=count; print age}' 2.parse
echo "Min Age: "
awk -F, 'BEGIN{min=200;}{if($5=="Male" && $6=="Black" && $4<=min) min=$4 }END{print min}' 2.parse
echo "Max Age: "
awk -F, 'BEGIN{max=0;}{if($5=="Male" && $6=="Black" && $4>=max) max=$4 }END{print max}' 2.parse

echo "----------"
echo "Black Female: "
echo "Total number: "
awk -F, 'BEGIN{count=0;}{if($5=="Female" && $6=="Black") count++;}END{print count}' 2.parse
echo "Average Age: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Female" && $6=="Black") count++;if($5=="Female" && $6=="Black") age+=$4;}END{age/=count; print age}' 2.parse
echo "Min Age: "
awk -F, 'BEGIN{min=200;}{if($5=="Female" && $6=="Black" && $4<=min) min=$4 }END{print min}' 2.parse
echo "Max Age: "
awk -F, 'BEGIN{max=0;}{if($5=="Female" && $6=="Black" && $4>=max) max=$4 }END{print max}' 2.parse

