def guess(text):
    letters = 'abcdefghijklmnopqrstuvwxyz'
    l = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    for letter in text:
        if letter in letters:
            num = letters.find(letter)
            l[num] = l[num] + 1
    
    dd = range(0,25)
    m = 0
    for j in dd:
        if m < l[j]:
            m = l[j]
            n = j

    if n <= 4:
        key = n + 26 - 4
    else:
        key = n - 4

    return key

def recover(text,key):
    result = ""
    for i in range(len(text)):
      char = text[i]
      if (char.isupper()):
         char = char.lower()
      if(char.isalpha()):
          if ord(char) - key < 0:
              result += char((ord(char) - key + 26 -97)%26 + 97)
          else:
              result += chr((ord(char) - key - 97) % 26 + 97)
      else:
         result += char
    return result

text = open("ceaser2.txt").read()
key = guess(text)
print ("The key number of the given input is: %d \n" %key)
print ("Recovered text: \n" + recover(text,key))
