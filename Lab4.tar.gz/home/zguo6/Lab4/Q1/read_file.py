from os import system
binary_file = open("/home/zguo6/Lab4/Q1/bi","rb").read()
f = open("./read_bi","wb")
f.write(binary_file)
f.close()

print("binary file: \n")
system("chmod 777 read_bi; cat read_bi")
