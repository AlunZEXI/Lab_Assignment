#include <stdio.h>
#include <stdlib.h>


int main() {
        int letter[26]={0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        char ch, list[2000];
FILE *fp;
int l=0;
fp = fopen("ceaser2.txt","r");
if(fp == NULL){
printf("Error \n");
exit(0);
}
while((ch = fgetc(fp)) != EOF){
list[l] = ch;
l++;
}
fclose(fp);

        int i;
        int len1 = sizeof(list);
for(i=0; i<len1; i++){
                int a = list[i]-97;
                letter[a]++;
        }

        int j;
        int maxindex;
        int max=0;
        int smaxindex;
        int smax=0;
        for(j=0; j<26; j++){
                if(letter[j] > max){
                        max=letter[j];
                        maxindex=j;
                }
                else if(letter[j] > smax && letter[j] < max){
                        smax=letter[j];
                        smaxindex=j;
                }
        }

        int key;
        key = maxindex - 4;
 if(key < 0){
                key += 25;
        }

        printf("The key number is: %d", key);
	int k;
        for(k=0; k<len1; k++){
                if(list[k] != ';' && list[k] != '!' && list[k] != '"' && list[k] != ' ' && list[k] != ',' && list[k] != '.'){
                        if(list[k]-key>=97){
                                list[k]-=key;
                        }
                        else{
                                list[k] = list[k] - key + 26;
                        }
            }
        }
        printf("%s" , list);

        return 0;
}
