num = raw_input("Please input your word(tens and units seperated by '-'): ")

if '-' in num:
    i = num.find('-')
    tens = num[0:i]
    units = num[i+1:len(num)]
    secdict = {
        "twenty":2,
        "thirty":3,
        "fourty":4,
        "fifty":5,
        "sixty":6,
        "seventy":7,
        "eighty":8,
        "ninety":9 
    }
    thirdict ={
        "one":1,
        "two":2,
        "three":3,
        "four":4,
        "five":5,
        "six":6,
        "seven":7,
        "eight":8,
        "nine":9
    }
    print("unsay: "+str(secdict[tens])+str(thirdict[units]))
else:
    firdict ={
        "eleven":11,
        "twelve":12,
        "thirteen":13,
        "fourteen":14,
        "fifteen":15,
        "sixteen":16,
        "seventeen":17,
        "eighteen":18,
        "nineteen":19,
        "ten":10,
        "twenty":20,
        "thirty":30,
        "fourty":40,
        "fifty":50,
        "sixty":60,
        "seventy":70,
        "eighty":80,
        "ninety":90,
        "zero":0,
        "one":1,
        "two":2,
        "three":3,
        "four":4,
        "five":5,
        "six":6,
        "seven":7,
        "eight":8,
        "nine":9
        }
    print("unsay: "+str(firdict[num]))
    
