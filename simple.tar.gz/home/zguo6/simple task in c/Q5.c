#include<stdio.h>

int main(){
int i;
int j;
int max;
for(i=100; i<1000; i++){
	for(j=100; j<1000; j++){
	int r=0;
	int res=i*j;
	int chun=res;
	while (res!=0){
	r=r*10;
	r=r+res%10;
	res=res/10;
	}
	if(r==chun){
		if(chun>max){
			max = chun;
		}
	}
}
}
printf("The largest palindrome made by the product of two three digit numbers is : %d", max);

return 0;
}
