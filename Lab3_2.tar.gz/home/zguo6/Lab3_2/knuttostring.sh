#!/bin/bash

awk '{
	symbol="";
	if(substr($0,1,1)=="-"){
		symbol="-";
	};
	
	gsub("-","",$0);

	gallon = int($0/23/17);
	remain = $0 % (23*17);
	sicle = int(remain/17);
	remain = remain % 17;
	knut = remain;

	output = symbol gallon "/" sicle "/" knut;
	print output;
}'
