#!/bin/bash
echo "Total men: "
awk -F, 'BEGIN{count=0;}{if($5=="Male") count+=1}END{print count}' 2.parse

echo "Total women: "
awk -F, 'BEGIN{count=0;}{if($5=="Female") count+=1}END{print count}' 2.parse


