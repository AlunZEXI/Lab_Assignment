#include<stdio.h>
#define max 1000
int main(){

printf("Input: ");

char input[max];
fgets(input, max, stdin);

printf("%s", input);

return 0;
}
