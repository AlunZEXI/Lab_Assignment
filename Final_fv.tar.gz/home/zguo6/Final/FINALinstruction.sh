#!/bin/bash
ls -la | egrep -v ^d >> output
awk '{if($1 != "total"){print $1, $9}else{print $0}}' output >> FINALinstruction
