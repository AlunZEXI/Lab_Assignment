import sys
read = raw_input("I will echo your words: ")
print(str(read))
