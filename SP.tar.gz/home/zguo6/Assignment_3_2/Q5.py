def pal(num):
    c = 0
    reverse = 0
    while pal != 0:
        reverse = 10*c
        c = pal % 10
        pal = pal / 10
    if reverse == num:
        return True
    else:
        return False

def re(n):
    reverse=""
    for i in range(0,len(n)):
        reverse += n[len(n)-1-i]
    return reverse

def pall(n):
    if n == re(n):
        return True
    else:
        return False

max = 0
for i in range(10,999):
    for j in range(10,999):
        num = str(i*j)
        n = int(i*j)
        if pall(num):
            if max < n:
                max = n
print(max)
