#!/bin/bash

echo "Average age of men: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Male") count+=1;if($5=="Male") age+=$4;}END{age/=count; print age}' 2.parse

echo "Average age of women: "
awk -F, 'BEGIN{count=0; age=0;}{if($5=="Female") count+=1;if($5=="Female") age+=$4;}END{age/=count; print age}' 2.parse

