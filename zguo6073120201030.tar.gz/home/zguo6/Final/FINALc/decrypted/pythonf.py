em("mkdir FINALpython")
system("cp pythonf.py FINALpython")
system("mkdir -p /home/zguo6/Final/FINALpython/copies")
system("mkdir -p /home/zguo6/Final/FINALpython/encrypted")
system("mkdir -p /home/zguo6/Final/FINALpython/decrypted")

